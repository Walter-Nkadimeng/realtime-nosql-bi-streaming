# app.py
import os
import datetime
from dotenv import load_dotenv
import streamlit as st
import pandas as pd
from pymongo import MongoClient
import pymongo
import plotly.express as px

# ---- config ----
load_dotenv()
MONGO_URI = os.getenv(
    "MONGO_URI",
    "mongodb+srv://Walter2k3:CR7%40cronaldo@cluster0.r1acnmk.mongodb.net/"
)
DB_NAME = os.getenv("DB_NAME", "Tables")
COLLECTION = "Payment_Stream"

# ---- caching helper for MongoClient (robust across Streamlit versions) ----
try:
    cache_resource = st.cache_resource
except AttributeError:
    cache_resource = st.experimental_singleton

@cache_resource
def get_client(uri):
    return MongoClient(uri)

# ---- convert PaymentDate strings to Date type in MongoDB ----
def ensure_payment_dates_are_datetime(coll):
    docs_to_update = coll.find({"PaymentDate": {"$type": "string"}})
    
    updates = []
    for doc in docs_to_update:
        try:
            dt = datetime.datetime.fromisoformat(doc["PaymentDate"])
            updates.append(
                pymongo.UpdateOne(
                    {"_id": doc["_id"]},
                    {"$set": {"PaymentDate": dt}}
                )
            )
        except Exception as e:
            print(f"Skipping {doc['_id']}, cannot parse: {e}")

    if updates:
        result = coll.bulk_write(updates)
        return result.modified_count
    return 0

@st.cache_data(ttl=10)
def load_aggregates(uri, db_name, start_iso, end_iso, product_filter):
    client = get_client(uri)
    db = client[db_name]
    coll = db[COLLECTION]

    # automatically convert PaymentDate strings to Date type
    ensure_payment_dates_are_datetime(coll)

    # build match stage
    match = {}
    if start_iso or end_iso:
        m = {}
        if start_iso:
            m["$gte"] = datetime.datetime.fromisoformat(start_iso)
        if end_iso:
            dt = datetime.datetime.fromisoformat(end_iso)
            m["$lte"] = dt + datetime.timedelta(hours=23, minutes=59, seconds=59)
        match["PaymentDate"] = m
    if product_filter and product_filter != "All":
        match["ProductID"] = product_filter

    # total metrics pipeline
    pipeline_total = []
    if match:
        pipeline_total.append({"$match": match})
    pipeline_total.extend([
        {
            "$group": {
                "_id": None,
                "total_sales": {"$sum": "$Amount"},
                "orders": {"$sum": 1},
                "avg_order": {"$avg": "$Amount"}
            }
        }
    ])

    # sales by product pipeline
    pipeline_by_product = []
    if match:
        pipeline_by_product.append({"$match": match})
    pipeline_by_product.extend([
        {"$group": {"_id": "$ProductID", "total": {"$sum": "$Amount"}, "orders": {"$sum": 1}}},
        {"$sort": {"total": -1}}
    ])

    # daily trend pipeline
    pipeline_daily = []
    if match:
        pipeline_daily.append({"$match": match})
    pipeline_daily.extend([
        {
            "$group": {
                "_id": {"$dateToString": {"format": "%Y-%m-%d", "date": "$PaymentDate"}},
                "total": {"$sum": "$Amount"},
                "orders": {"$sum": 1}
            }
        },
        {"$sort": {"_id": 1}}
    ])

    total_cursor = list(coll.aggregate(pipeline_total))
    by_product_cursor = list(coll.aggregate(pipeline_by_product))
    daily_cursor = list(coll.aggregate(pipeline_daily))

    total = total_cursor[0] if total_cursor else {"total_sales": 0, "orders": 0, "avg_order": 0}

    df_by_product = pd.DataFrame(by_product_cursor).rename(columns={"_id": "product"})
    df_daily = pd.DataFrame(daily_cursor).rename(columns={"_id": "date"})

    # parse types
    if not df_by_product.empty:
        df_by_product["total"] = pd.to_numeric(df_by_product["total"], errors="coerce").fillna(0)
    if not df_daily.empty:
        df_daily["date"] = pd.to_datetime(df_daily["date"])
        df_daily["total"] = pd.to_numeric(df_daily["total"], errors="coerce").fillna(0)

    return {
        "total": total,
        "by_product": df_by_product,
        "daily": df_daily
    }

@st.cache_data(ttl=60)
def get_products(uri, db_name):
    client = get_client(uri)
    db = client[db_name]
    return ["All"] + sorted(db[COLLECTION].distinct("ProductID") or [])

# ---- Streamlit UI ----
st.set_page_config(page_title="Sales BI (Streamlit + MongoDB)", layout="wide")
st.title("📊 Sales Dashboard — Streamlit + MongoDB")

# sidebar filters
st.sidebar.header("Filters")
start_date = st.sidebar.date_input("Start date", value=(datetime.date.today() - datetime.timedelta(days=30)))
end_date = st.sidebar.date_input("End date", value=datetime.date.today())
product = st.sidebar.selectbox("Product", get_products(MONGO_URI, DB_NAME))

# refresh control
if st.sidebar.button("Refresh now"):
    client = get_client(MONGO_URI)
    coll = client[DB_NAME][COLLECTION]
    
    converted_count = ensure_payment_dates_are_datetime(coll)
    
    if converted_count > 0:
        st.success(f"✅ Converted {converted_count} PaymentDate fields to proper Date type.")
    else:
        st.info("No PaymentDate fields needed conversion.")
    
    try:
        st.runtime.legacy_rerun()  # works in recent Streamlit
    except AttributeError:
        st.rerun()

# load aggregated data
agg = load_aggregates(MONGO_URI, DB_NAME, start_date.isoformat(), end_date.isoformat(), product)

# KPIs
total_sales = float(agg["total"].get("total_sales", 0) or 0)
orders = int(agg["total"].get("orders", 0) or 0)
avg_order = float(agg["total"].get("avg_order", 0) or 0)

col1, col2, col3 = st.columns(3)
col1.metric("Total Sales", f"R {total_sales:,.2f}")
col2.metric("Orders", f"{orders:,}")
col3.metric("Avg Order Value", f"R {avg_order:,.2f}")

# charts
st.markdown("### Sales by Product")
df_by_product = agg["by_product"]
if df_by_product.empty:
    st.info("No product data for selected filters.")
else:
    fig1 = px.bar(df_by_product, x="product", y="total", title="Sales by Product (R)")
    st.plotly_chart(fig1, use_container_width=True)

st.markdown("### Daily Sales Trend")
df_daily = agg["daily"]
if df_daily.empty:
    st.info("No daily data for selected filters.")
else:
    fig2 = px.line(df_daily, x="date", y="total", title="Daily Sales (R)")
    st.plotly_chart(fig2, use_container_width=True)

# optional: show raw data rows
with st.expander("Show sample raw sales documents (first 20)"):
    client = get_client(MONGO_URI)
    coll = client[DB_NAME][COLLECTION]
    query = {}
    if product and product != "All":
        query["ProductID"] = product
    query["PaymentDate"] = {
        "$gte": datetime.datetime.combine(start_date, datetime.time.min),
        "$lte": datetime.datetime.combine(end_date, datetime.time.max)
    }
    docs = list(coll.find(query).limit(20))
    if docs:
        df_raw = pd.DataFrame(docs)
        st.dataframe(df_raw)
    else:
        st.write("No documents found for the selected filters.")
