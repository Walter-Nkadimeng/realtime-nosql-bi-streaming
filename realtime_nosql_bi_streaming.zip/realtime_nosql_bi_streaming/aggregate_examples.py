# aggregate_examples.py
import time
from pymongo import MongoClient

# === CONFIGURATION ===
MONGO_URI = "mongodb+srv://Walter2k3:CR7%40cronaldo@cluster0.r1acnmk.mongodb.net/"
DB_NAME = "Tables"
COLLECTION_NAME = "Payment_Stream"
REFRESH_INTERVAL = 5  # seconds

# Connect to MongoDB
client = MongoClient(MONGO_URI)
db = client[DB_NAME]
collection = db[COLLECTION_NAME]

print("📊 Real-Time Aggregator started. Press CTRL+C to stop.\n")

while True:
    try:
        # Total payments
        total_payments = collection.count_documents({})

        # Total revenue
        pipeline_total = [
            {"$group": {"_id": None, "total_amount": {"$sum": "$Amount"}}}
        ]
        result_total = list(collection.aggregate(pipeline_total))
        total_revenue = result_total[0]["total_amount"] if result_total else 0

        # Average payment amount
        pipeline_avg = [
            {"$group": {"_id": None, "avg_amount": {"$avg": "$Amount"}}}
        ]
        result_avg = list(collection.aggregate(pipeline_avg))
        avg_amount = result_avg[0]["avg_amount"] if result_avg else 0

        # Revenue by payment method
        pipeline_method = [
            {"$group": {"_id": "$Method", "total": {"$sum": "$Amount"}}}
        ]
        revenue_by_method = {doc["_id"]: doc["total"] for doc in collection.aggregate(pipeline_method)}

        # Revenue by region
        pipeline_region = [
            {"$group": {"_id": "$Region", "total": {"$sum": "$Amount"}}}
        ]
        revenue_by_region = {doc["_id"]: doc["total"] for doc in collection.aggregate(pipeline_region)}

        # Clear console (optional, Windows-friendly)
        print("\033c", end="")  # works in most terminals
        print("📊 Real-Time Payment Metrics\n")
        print(f"Total Payments: {total_payments}")
        print(f"Total Revenue: ${total_revenue:,.2f}")
        print(f"Average Payment Amount: ${avg_amount:,.2f}\n")
        print("Revenue by Payment Method:")
        for method, amount in revenue_by_method.items():
            print(f"  {method}: ${amount:,.2f}")
        print("\nRevenue by Region:")
        for region, amount in revenue_by_region.items():
            print(f"  {region}: ${amount:,.2f}")

        time.sleep(REFRESH_INTERVAL)

    except KeyboardInterrupt:
        print("\nStopped Real-Time Aggregator.")
        break
    except Exception as e:
        print(f"Error: {e}")
        time.sleep(REFRESH_INTERVAL)
