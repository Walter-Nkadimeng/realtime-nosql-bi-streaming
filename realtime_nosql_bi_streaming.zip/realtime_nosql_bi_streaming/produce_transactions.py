import sys
import io

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# produce_transactions.py
import json
import time
import random
from datetime import datetime

# Simulate streaming real-time payment data
print(" Starting Payment Stream... (press CTRL+C to stop)")

while True:
    payment = {
        "PaymentID": random.randint(1000, 9999),
        "CustomerID": random.randint(1, 50),
        "ProductID": random.randint(100, 500),
        "Amount": round(random.uniform(100.00, 2000.00), 2),
        "PaymentDate": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "Method": random.choice(["EFT", "Credit Card", "Cash", "Debit"]),
        "Region": random.choice(["North", "South", "East", "West"])
    }

    # Output as JSON (simulates stream data)
    print(json.dumps(payment), flush=True)

    # Wait a few seconds before next record
    time.sleep(3)
