# consume_to_mongo.py
import sys
import json
from pymongo import MongoClient
from datetime import datetime

# === CONFIGURATION ===
MONGO_URI = "mongodb+srv://Walter2k3:CR7%40cronaldo@cluster0.r1acnmk.mongodb.net/"
DB_NAME = "Tables"
COLLECTION_NAME = "Payment_Stream"

# Connect to MongoDB
client = MongoClient(MONGO_URI)
db = client[DB_NAME]
collection = db[COLLECTION_NAME]

print(" Consumer started. Waiting for transactions...")

for line in sys.stdin:
    try:
        transaction = json.loads(line.strip())
        transaction['received_at'] = datetime.now()
        collection.insert_one(transaction)
        print(f"Inserted: {transaction}")
    except Exception as e:
        print(f"Error inserting transaction: {e}")
